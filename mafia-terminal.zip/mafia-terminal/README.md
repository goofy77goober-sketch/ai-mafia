# The Village Sleeps — Mafia Terminal

A full Mafia game in your terminal, powered by Ollama (gemma3:4b).

## Requirements
- Node.js 18+
- Ollama running locally with gemma3:4b pulled

## Setup
```bash
# 1. Make sure Ollama is running
ollama serve

# 2. Make sure gemma3:4b is pulled
ollama pull gemma3:4b

# 3. Install dependencies
npm install

# 4. Play!
npm start
```

## Controls
- **Setup**: Type your name, press Enter. Type model name, press Enter.
- **Day discussion**: Read what AI players say, then type your statement + Enter.
- **Voting**: ↑↓ arrows to pick a suspect, Enter to vote.
- **Night action**: ↑↓ to pick your target, Enter to confirm.
- **Win screen**: [r] to restart, [q] to quit.

## Roles (7 players: you + 6 AI)
- **Mafia ×2** — Know each other. Kill one person per night.
- **Detective ×1** — Investigate one player per night.
- **Doctor ×1** — Protect one player per night.
- **Villager ×3** — Use logic to find the Mafia.

// ═══════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════
export type Role = 'mafia' | 'detective' | 'doctor' | 'villager';

export interface Player {
  id: number;
  name: string;
  isHuman: boolean;
  role: Role;
  alive: boolean;
  personality: string;
  number: number;
}

export interface LogEntry {
  type: 'system' | 'speech' | 'death' | 'save' | 'reveal' | 'night' | 'thinking';
  speaker?: string;
  text: string;
  isYou?: boolean;
}

// A record of what happened each day/night cycle
export interface DayRecord {
  day: number;
  eliminated: { name: string; role: Role } | null;   // voted out
  killed:     { name: string; role: Role } | null;   // night kill
  saved:      boolean;                                // doctor saved someone
  votes: { voterName: string; targetName: string }[]; // who voted for whom
}

export interface GameState {
  model: string;
  players: Player[];
  day: number;
  log: LogEntry[];
  investigateResults: Record<number, 'mafia' | 'innocent'>;
  history: DayRecord[];   // ← NEW: full game history
}

// ═══════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════
export const AI_NAMES = ['Aldric', 'Maren', 'Severin', 'Lucca', 'Brenna', 'Dagny'];

export const PERSONALITIES = [
  'nervous and talkative, suspects everyone, often contradicts yourself',
  'calm and analytical, speaks in measured sentences, asks pointed questions',
  'hot-headed and accusatory, quick to point fingers, gets defensive when challenged',
  'quiet and evasive, gives short answers, subtly deflects suspicion onto others',
  'overly friendly and consensus-seeking, tries to calm tensions, hates conflict',
  'logical and methodical, cites evidence, deeply skeptical of emotional arguments',
];

// ═══════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════
export function createGame(playerName: string, model: string): GameState {
  const roles: Role[] = shuffle(['mafia','mafia','detective','doctor','villager','villager','villager'] as Role[]);
  const names = shuffle([...AI_NAMES]);
  const personalities = shuffle([...PERSONALITIES]);

  const players: Player[] = [
    { id: 0, name: playerName, isHuman: true, role: roles[0], alive: true, personality: 'human', number: 0 },
    ...names.map((name, i) => ({
      id: i + 1, name, isHuman: false, role: roles[i + 1],
      alive: true, personality: personalities[i], number: i + 1,
    })),
  ];

  return { model, players, day: 1, log: [], investigateResults: {}, history: [] };
}

// ═══════════════════════════════════════════════
// DISPLAY NAME  (??? until revealed)
// ═══════════════════════════════════════════════
export function displayName(p: Player, G: GameState): string {
  if (p.isHuman) return p.name;
  if (!p.alive) return p.name;
  const human = G.players[0];
  if (human.role === 'mafia' && p.role === 'mafia') return p.name;
  if (G.investigateResults[p.id]) return p.name;
  return `??? #${p.number}`;
}

// ═══════════════════════════════════════════════
// OLLAMA
// ═══════════════════════════════════════════════
export async function askOllama(model: string, prompt: string, retries = 4): Promise<string> {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch('http://localhost:11434/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model, stream: false,
          messages: [{ role: 'user', content: prompt }],
          options: { temperature: 0.85, num_predict: 80 },
        }),
      });
      if (!res.ok) {
        const delay = res.status === 500 ? 3000 : 800;
        if (attempt < retries) { await sleep(delay); continue; }
        throw new Error(`HTTP ${res.status}`);
      }
      const data = await res.json();
      return data.message?.content?.trim() || '';
    } catch (e: any) {
      if (attempt === retries) return `[Ollama error: ${e.message}]`;
      await sleep(900);
    }
  }
  return '[error]';
}

// ═══════════════════════════════════════════════
// AI CONTEXT  — the real upgrade
// ═══════════════════════════════════════════════
export function buildContext(G: GameState, forPlayer: Player): string {
  const alive = G.players.filter(p => p.alive).map(p => p.name).join(', ');
  const dead  = G.players.filter(p => !p.alive).map(p => `${p.name} (was ${p.role})`).join(', ') || 'nobody yet';

  // Role briefing
  let roleBriefing = '';
  if (forPlayer.role === 'mafia') {
    const partner = G.players.find(p => p.role === 'mafia' && p.id !== forPlayer.id);
    roleBriefing = `YOUR ROLE: MAFIA. Your secret partner is ${partner?.name ?? 'unknown'}. You must appear innocent and deflect suspicion. Vote strategically to protect each other.`;
  } else if (forPlayer.role === 'detective') {
    const known = Object.entries(G.investigateResults)
      .map(([id, r]) => { const p = G.players.find(x => x.id === +id); return p ? `${p.name} = ${r}` : ''; })
      .filter(Boolean).join(', ');
    roleBriefing = `YOUR ROLE: DETECTIVE. Your private investigation results: ${known || 'none yet'}. Use this knowledge wisely but don't reveal your role outright.`;
  } else if (forPlayer.role === 'doctor') {
    roleBriefing = `YOUR ROLE: DOCTOR. You protect someone each night. During the day, act like a villager — don't reveal your role.`;
  } else {
    roleBriefing = `YOUR ROLE: VILLAGER. You have no special information. Reason carefully from what you observe.`;
  }

  // Game history — eliminations, kills, votes
  let historySection = '';
  if (G.history.length > 0) {
    historySection = '\nGAME HISTORY (use this to reason and accuse):';
    for (const rec of G.history) {
      historySection += `\n  Day ${rec.day}:`;
      if (rec.eliminated) {
        historySection += ` ${rec.eliminated.name} was voted out (was ${rec.eliminated.role}).`;
      } else {
        historySection += ` No one was voted out.`;
      }
      if (rec.votes.length > 0) {
        historySection += ` Votes cast: ${rec.votes.map(v => `${v.voterName}→${v.targetName}`).join(', ')}.`;
      }
      if (rec.killed) {
        historySection += ` That night, ${rec.killed.name} (${rec.killed.role}) was killed.`;
      } else if (rec.saved) {
        historySection += ` That night, someone was targeted but saved by the Doctor.`;
      } else {
        historySection += ` That night, nobody was killed.`;
      }
    }
  }

  // Recent speeches
  const recent = G.log.filter(e => e.type === 'speech').slice(-6)
    .map(e => `  ${e.speaker}: ${e.text}`).join('\n');

  return `
=== GAME STATE ===
Day: ${G.day}
Alive: ${alive}
Dead: ${dead}
${historySection}

=== YOUR BRIEFING ===
${roleBriefing}

=== RECENT DISCUSSION ===
${recent || '  (none yet)'}
`.trim();
}

// ═══════════════════════════════════════════════
// AI SPEECHES & VOTES
// ═══════════════════════════════════════════════
export async function getAISpeech(G: GameState, player: Player): Promise<string> {
  const ctx = buildContext(G, player);
  return askOllama(G.model, `You are ${player.name} playing Mafia in a village setting. Personality: ${player.personality}.

${ctx}

It is Day ${G.day}. Speak 1-2 sentences in character. Reference specific game events, past votes, or suspicious behavior where relevant. Be accusatory, defensive, or probe others — but stay in character. Do NOT say you are an AI or mention game mechanics directly.`
  );
}

export async function getAIDefense(G: GameState, player: Player): Promise<string> {
  const ctx = buildContext(G, player);
  return askOllama(G.model, `You are ${player.name} playing Mafia. Personality: ${player.personality}.

${ctx}

You are TIED for elimination and must defend yourself RIGHT NOW. Give your most convincing 1-2 sentence argument for why you should be spared. Reference the game history and other players' suspicious behavior if helpful.`
  );
}

export async function getAIVote(G: GameState, player: Player, excludeIds: number[] = []): Promise<number> {
  const ctx = buildContext(G, player);
  const targets = G.players.filter(p => p.alive && p.id !== player.id && !excludeIds.includes(p.id));
  if (!targets.length) {
    const fallback = G.players.filter(p => p.alive && p.id !== player.id);
    return fallback[Math.floor(Math.random() * fallback.length)]?.id ?? 0;
  }
  const names = targets.map(p => p.name).join(', ');
  const resp = await askOllama(G.model, `You are ${player.name} in Mafia.

${ctx}

Time to vote. Alive players you can vote for: ${names}.
Consider the game history and suspicious behavior. Reply with ONLY the exact name of who you are voting for.`
  );
  const match = targets.find(p => resp.toLowerCase().includes(p.name.toLowerCase()));
  return match ? match.id : targets[Math.floor(Math.random() * targets.length)].id;
}

export async function getAIMafiaKill(G: GameState): Promise<number | null> {
  const killer = G.players.find(p => p.alive && !p.isHuman && p.role === 'mafia');
  if (!killer) return null;
  const targets = G.players.filter(p => p.alive && p.role !== 'mafia');
  if (!targets.length) return null;
  const ctx = buildContext(G, killer);
  const names = targets.map(p => p.name).join(', ');
  const resp = await askOllama(G.model, `You are ${killer.name}, a Mafia member.

${ctx}

It is night. Choose ONE player to eliminate. Options: ${names}.
Prioritize killing the Detective or Doctor if you suspect who they are. Reply ONLY with the name.`
  );
  const match = targets.find(p => resp.toLowerCase().includes(p.name.toLowerCase()));
  return match ? match.id : targets[Math.floor(Math.random() * targets.length)].id;
}

export function getAIDetectiveTarget(G: GameState): number | null {
  const det = G.players.find(p => p.alive && !p.isHuman && p.role === 'detective');
  if (!det) return null;
  // Prefer uninvestigated players who voted suspiciously
  const pool = G.players.filter(p => p.alive && p.id !== det.id && !G.investigateResults[p.id]);
  if (!pool.length) return null;
  // Bias toward players with no clear vote pattern (could be mafia lying low)
  return pool[Math.floor(Math.random() * pool.length)].id;
}

export function getAIDoctorTarget(G: GameState): number | null {
  const doc = G.players.find(p => p.alive && !p.isHuman && p.role === 'doctor');
  if (!doc) return null;
  // Prefer to protect players who were recently accused (likely targeted)
  const pool = G.players.filter(p => p.alive);
  return pool[Math.floor(Math.random() * pool.length)].id;
}

// ═══════════════════════════════════════════════
// WIN CHECK & TALLY
// ═══════════════════════════════════════════════
export function checkWin(G: GameState): 'town' | 'mafia' | null {
  const m = G.players.filter(p => p.alive && p.role === 'mafia').length;
  const t = G.players.filter(p => p.alive && p.role !== 'mafia').length;
  if (m === 0) return 'town';
  if (m >= t) return 'mafia';
  return null;
}

export function tallyVotes(votes: number[]): Record<number, number> {
  const tally: Record<number, number> = {};
  votes.forEach(id => { tally[id] = (tally[id] || 0) + 1; });
  return tally;
}

export function topVoted(tally: Record<number, number>): number[] {
  if (!Object.keys(tally).length) return [];
  const max = Math.max(...Object.values(tally));
  return Object.entries(tally).filter(([, v]) => v === max).map(([k]) => parseInt(k));
}

// ═══════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════
export function shuffle<T>(arr: T[]): T[] {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms));
}

#!/usr/bin/env node
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { render, Box, Text, useInput, useApp } from 'ink';
import TextInput from 'ink-text-input';
import {
  createGame, checkWin, tallyVotes, topVoted, displayName,
  getAISpeech, getAIDefense, getAIVote, getAIMafiaKill,
  getAIDetectiveTarget, getAIDoctorTarget,
  shuffle, sleep,
  type GameState, type Player, type Role, type LogEntry, type DayRecord,
} from './game.ts';

// ═══════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════
const ROLE_COLOR: Record<string, string> = {
  mafia: 'red', detective: 'blue', doctor: 'green', villager: 'yellow',
};
const rc = (r: string) => ROLE_COLOR[r] || 'white';
const WHEEL_SEQ: Role[] = ['villager','mafia','doctor','detective','villager','mafia','doctor','detective','villager','mafia','villager','detective'];
const SPINNERS = ['◐','◓','◑','◒'];

// ═══════════════════════════════════════════════
// TINY SHARED UI PIECES
// ═══════════════════════════════════════════════
function HR({ color = 'grey' }: { color?: string }) {
  return <Text color={color}>{'─'.repeat(60)}</Text>;
}

function PlayerRoster({ G, selectedId, showCursor }: {
  G: GameState; selectedId?: number; showCursor?: boolean;
}) {
  const human = G.players[0];
  return (
    <Box flexDirection="column" marginBottom={1}>
      <Text color="grey" dimColor>Players ─────────────────────────────────</Text>
      {G.players.map(p => {
        const dname = displayName(p, G);
        const sel = showCursor && p.id === selectedId;
        const dead = !p.alive;
        let hint = '';
        if (p.isHuman) hint = ` [${p.role}]`;
        else if (dead) hint = ` [${p.role} ✝]`;
        else if (human.role === 'mafia' && p.role === 'mafia') hint = ' [partner ☠]';
        else if (G.investigateResults[p.id]) hint = ` [${G.investigateResults[p.id] === 'mafia' ? '⚠ mafia' : '✓ innocent'}]`;
        return (
          <Box key={p.id}>
            <Text color={sel ? 'yellow' : 'grey'}>{sel ? '▶ ' : '  '}</Text>
            <Text color={dead ? 'grey' : sel ? 'yellowBright' : 'white'} bold={sel}>
              {dname}
            </Text>
            {hint ? <Text color={dead ? 'grey' : rc(p.role)} dimColor>{hint}</Text> : null}
          </Box>
        );
      })}
    </Box>
  );
}

function GameLog({ log }: { log: LogEntry[] }) {
  const show = log.slice(-10);
  return (
    <Box flexDirection="column" borderStyle="single" borderColor="grey" paddingX={1} marginBottom={1}>
      <Text color="grey" dimColor>Log ─────────────────────────────────────</Text>
      {show.length === 0 && <Text color="grey" dimColor>  —</Text>}
      {show.map((e, i) => {
        if (e.type === 'thinking') return <Text key={i} color="grey" dimColor italic>  {e.speaker}: ...</Text>;
        if (e.type === 'system')   return <Text key={i} color="grey" italic>  {e.text}</Text>;
        if (e.type === 'death')    return <Text key={i} color="red" italic>  ✝ {e.text}</Text>;
        if (e.type === 'save')     return <Text key={i} color="green" italic>  ✦ {e.text}</Text>;
        if (e.type === 'reveal')   return <Text key={i} color="yellow">  ★ {e.text}</Text>;
        if (e.type === 'night')    return <Text key={i} color="blue" dimColor>  {e.text}</Text>;
        return (
          <Text key={i} color={e.isYou ? 'yellowBright' : 'white'}>
            {'  '}<Text bold>{e.speaker}</Text>{': '}{e.text}
          </Text>
        );
      })}
    </Box>
  );
}

// ═══════════════════════════════════════════════
// SCREEN: SETUP
// ═══════════════════════════════════════════════
function SetupScreen({ onStart }: { onStart: (name: string, model: string) => void }) {
  const [name, setName] = useState('');
  const [model, setModel] = useState('gemma3:4b');
  const [step, setStep] = useState<'name' | 'model'>('name');

  useInput((_, key) => {
    if (!key.return) return;
    if (step === 'name') setStep('model');
    else onStart(name.trim() || 'Stranger', model.trim() || 'gemma3:4b');
  });

  return (
    <Box flexDirection="column" padding={2}>
      <Text color="yellowBright" bold>THE VILLAGE SLEEPS  —  MAFIA</Text>
      <HR />
      <Box marginTop={1} />
      <Text color="grey">7 players  ·  2 Mafia  ·  1 Detective  ·  1 Doctor  ·  3 Villagers</Text>
      <Box marginTop={1} />
      <Box><Text color="white">Your name:    </Text>
        {step === 'name'
          ? <TextInput value={name} onChange={setName} placeholder="Enter name…" />
          : <Text color="yellow">{name || 'Stranger'}</Text>}
      </Box>
      {step === 'model' && (
        <Box marginTop={1}><Text color="white">Ollama model: </Text>
          <TextInput value={model} onChange={setModel} placeholder="gemma3:4b" />
        </Box>
      )}
      <Box marginTop={1} />
      <Text color="grey" italic>Press Enter to continue…</Text>
    </Box>
  );
}

// ═══════════════════════════════════════════════
// SCREEN: WHEEL
// ═══════════════════════════════════════════════
function WheelScreen({ role, onDone }: { role: Role; onDone: () => void }) {
  const [label, setLabel] = useState('VILLAGER   ');
  const [spinChar, setSpinChar] = useState('◐');
  const [stage, setStage] = useState<'spin'|'reveal'|'done'>('spin');
  const [color, setColor] = useState<string>('grey');
  const frame   = useRef(0);
  const tick    = useRef(0);
  const roleIdx = useRef(0);
  const done    = useRef(false);

  useEffect(() => {
    const id = setInterval(() => {
      if (done.current) return;
      tick.current++;
      frame.current = (frame.current + 1) % 4;
      setSpinChar(SPINNERS[frame.current]);

      if (tick.current <= 30) {
        // fast spin
        roleIdx.current = (roleIdx.current + 1) % WHEEL_SEQ.length;
        setLabel(WHEEL_SEQ[roleIdx.current].toUpperCase().padEnd(11));
      } else if (tick.current <= 46) {
        // slow down — step every other tick
        if (tick.current % 2 === 0) {
          roleIdx.current = (roleIdx.current + 1) % WHEEL_SEQ.length;
          setLabel(WHEEL_SEQ[roleIdx.current].toUpperCase().padEnd(11));
        }
      } else {
        // stop & reveal
        clearInterval(id);
        done.current = true;
        setLabel(role.toUpperCase().padEnd(11));
        setStage('reveal');
        setColor(rc(role));
        setTimeout(() => { setStage('done'); }, 200);
        setTimeout(onDone, 2400);
      }
    }, 80);

    return () => clearInterval(id);
  }, []);

  return (
    <Box flexDirection="column" alignItems="center" paddingY={3}>
      <Text color="yellowBright" bold>THE VILLAGE SLEEPS</Text>
      <Box marginTop={1}><HR /></Box>
      <Box marginTop={2} />
      <Text color="grey" italic>The fates are deciding your role…</Text>
      <Box marginTop={2} />
      <Box borderStyle="double" borderColor={stage === 'spin' ? 'grey' : color} paddingX={5} paddingY={1}>
        <Text color={stage === 'spin' ? 'grey' : color} bold>
          {stage === 'spin'
            ? `${spinChar}  ${label}  ${SPINNERS[(frame.current + 2) % 4]}`
            : stage === 'reveal'
            ? `✦  ${label}  ✦`
            : `★  ${label}  ★`}
        </Text>
      </Box>
      {stage === 'done' && (
        <Box flexDirection="column" alignItems="center" marginTop={2}>
          <Text color={color} bold>You are the {role.toUpperCase()}.</Text>
          <Box marginTop={1} />
          {role === 'mafia'     && <Text color="red"    italic>Stay hidden. Eliminate the village from within.</Text>}
          {role === 'detective' && <Text color="blue"   italic>Each night, investigate one player. Find the Mafia.</Text>}
          {role === 'doctor'    && <Text color="green"  italic>Each night, protect one player from being killed.</Text>}
          {role === 'villager'  && <Text color="yellow" italic>Trust your gut. Root out the Mafia before it's too late.</Text>}
          <Box marginTop={1} />
          <Text color="grey" dimColor italic>The village stirs…</Text>
        </Box>
      )}
    </Box>
  );
}

// ═══════════════════════════════════════════════
// SCREEN: WIN
// ═══════════════════════════════════════════════
function WinScreen({ winner, G, onRestart }: { winner: 'town'|'mafia'; G: GameState; onRestart: () => void }) {
  const { exit } = useApp();
  useInput((ch) => { if (ch === 'r') onRestart(); if (ch === 'q') exit(); });
  return (
    <Box flexDirection="column" padding={2}>
      <Text color={winner === 'town' ? 'greenBright' : 'redBright'} bold>
        {winner === 'town' ? '★  THE VILLAGE PREVAILS' : '☠   DARKNESS TAKES THE VILLAGE'}
      </Text>
      <Box marginTop={1} />
      <Text color="grey">The truth is revealed:</Text>
      {G.players.map(p => (
        <Box key={p.id}>
          <Text color="grey">  </Text>
          <Text color={p.alive ? 'white' : 'grey'}>{p.name}{p.isHuman ? ' (you)' : ''}</Text>
          <Text color="grey"> — </Text>
          <Text color={rc(p.role)}>{p.role}</Text>
          {!p.alive && <Text color="grey"> ✝</Text>}
        </Box>
      ))}
      <Box marginTop={1} />
      <Text color="grey" italic>[r] play again  [q] quit</Text>
    </Box>
  );
}

// ═══════════════════════════════════════════════
// MAIN GAME ENGINE
// ═══════════════════════════════════════════════

// UI state shape
type UIMode =
  | { tag: 'idle'; status: string }
  | { tag: 'speak' }
  | { tag: 'select'; targets: Player[]; prompt: string; onSelect: (id: number) => void }
  | { tag: 'night-narrate'; lines: {text:string;color:string}[]; shown: number }
  | { tag: 'tiebreak'; accused: Player[]; prompt: string; onSelect: (id: number) => void; targets: Player[] };

function GameScreen({ initialG, onRestart }: { initialG: GameState; onRestart: () => void }) {
  const [G, setG]       = useState<GameState>(initialG);
  const [ui, setUI]     = useState<UIMode>({ tag: 'idle', status: 'Starting…' });
  const [winner, setWinner] = useState<'town'|'mafia'|null>(null);
  const [speakText, setSpeakText] = useState('');
  const [cursorIdx, setCursorIdx] = useState(0);

  // Refs for the async game loop to read latest state
  const gRef  = useRef(G);
  const uiRef = useRef(ui);
  gRef.current = G;
  uiRef.current = ui;

  // Resolve functions for human input (set by game loop, called by UI)
  const resolveInput = useRef<((val: string | number) => void) | null>(null);

  // ── Mutators ──────────────────────────────────
  const addLog = useCallback((entry: LogEntry) => {
    setG(prev => ({ ...prev, log: [...prev.log, entry] }));
  }, []);

  const removeThinking = useCallback((speaker: string) => {
    setG(prev => ({ ...prev, log: prev.log.filter(e => !(e.type === 'thinking' && e.speaker === speaker)) }));
  }, []);

  const mutateG = useCallback((fn: (g: GameState) => GameState) => {
    setG(prev => { const n = fn(prev); gRef.current = n; return n; });
  }, []);

  // ── Human input helpers (return Promises) ─────
  const waitForSpeak = (): Promise<string> => new Promise(res => {
    setUI({ tag: 'speak' });
    resolveInput.current = (v) => res(v as string);
  });

  const waitForSelect = (targets: Player[], prompt: string): Promise<number> => new Promise(res => {
    setCursorIdx(0);
    setUI({ tag: 'select', targets, prompt, onSelect: (id) => res(id) });
    resolveInput.current = (v) => res(v as number);
  });

  const waitForTiebreak = (accused: Player[], targets: Player[], prompt: string): Promise<number> => new Promise(res => {
    setCursorIdx(0);
    setUI({ tag: 'tiebreak', accused, targets, prompt, onSelect: (id) => res(id) });
    resolveInput.current = (v) => res(v as number);
  });

  // ── Keyboard handler ──────────────────────────
  useInput((_ch, key) => {
    const u = uiRef.current;
    if (u.tag === 'select' || u.tag === 'tiebreak') {
      const targets = u.tag === 'select' ? u.targets : u.targets;
      if (key.upArrow)   setCursorIdx(i => Math.max(0, i - 1));
      if (key.downArrow) setCursorIdx(i => Math.min(targets.length - 1, i + 1));
      if (key.return) {
        const sel = targets[cursorIdx];
        if (sel) {
          u.onSelect(sel.id);
          resolveInput.current?.(sel.id);
          resolveInput.current = null;
        }
      }
    }
  });

  // ── Night narration helper ────────────────────
  const playNarration = (lines: {text:string;color:string}[]): Promise<void> => new Promise(async res => {
    setUI({ tag: 'night-narrate', lines, shown: 0 });
    for (let i = 0; i < lines.length; i++) {
      await sleep(lines[i].color === 'grey' ? 800 : 1000);
      setUI({ tag: 'night-narrate', lines, shown: i + 1 });
    }
    await sleep(700);
    res();
  });

  // ══════════════════════════════════════════════
  // GAME LOOP — runs once on mount
  // ══════════════════════════════════════════════
  useEffect(() => {
    runGame();
  }, []);

  async function runGame() {
    let g = gRef.current;

    while (true) {
      // ── DAY DISCUSSION ────────────────────────
      setUI({ tag: 'idle', status: 'The village is in discussion…' });
      const speakers = shuffle(g.players.filter(p => p.alive && !p.isHuman)).slice(0, 3);

      for (const sp of speakers) {
        if (checkWin(gRef.current)) break;
        addLog({ type: 'thinking', speaker: sp.name, text: '…' });
        const speech = await getAISpeech(gRef.current, sp);
        removeThinking(sp.name);
        addLog({ type: 'speech', speaker: displayName(sp, gRef.current), text: speech });
        await sleep(150);
      }

      g = gRef.current;
      const w0 = checkWin(g);
      if (w0) { setWinner(w0); return; }

      // ── YOUR STATEMENT ────────────────────────
      const human = g.players[0];
      if (human.alive) {
        setUI({ tag: 'idle', status: 'Type your statement, then press Enter.' });
        const stmt = await waitForSpeak();
        addLog({ type: 'speech', speaker: `${human.name} (you)`, text: stmt, isYou: true });
      }

      // ── VOTING ───────────────────────────────
      g = gRef.current;
      const currentDay = g.day;
      const { elimId, voteLog } = await runVoting(g);

      g = gRef.current;
      const w1 = checkWin(g);
      if (w1) { setWinner(w1); return; }

      // ── NIGHT ────────────────────────────────
      const nightResult = await runNight(g);

      g = gRef.current;
      const w2 = checkWin(g);
      if (w2) { setWinner(w2); return; }

      // ── RECORD HISTORY ───────────────────────
      const elimPlayer = elimId != null ? gRef.current.players.find(p => p.id === elimId) : null;
      const dayRecord: DayRecord = {
        day: currentDay,
        eliminated: elimPlayer ? { name: elimPlayer.name, role: elimPlayer.role } : null,
        killed: nightResult.killed,
        saved: nightResult.saved,
        votes: voteLog,
      };
      mutateG(prev => ({ ...prev, history: [...prev.history, dayRecord], day: prev.day + 1 }));
      g = gRef.current;
      addLog({ type: 'system', text: `Day ${g.day} begins.` });
    }
  }

  // ══════════════════════════════════════════════
  // VOTING PHASE
  // ══════════════════════════════════════════════
  async function runVoting(g: GameState, excludeIds: number[] = []): Promise<{ elimId: number | null; voteLog: { voterName: string; targetName: string }[] }> {
    setUI({ tag: 'idle', status: 'Gathering votes…' });
    const human = g.players[0];
    const votes: number[] = [];
    const voteLog: { voterName: string; targetName: string }[] = [];

    // Human votes (if alive)
    if (human.alive) {
      const vTargets = g.players.filter(p => p.alive && !p.isHuman && !excludeIds.includes(p.id));
      const chosenId = await waitForSelect(vTargets, '↑↓ to choose, Enter to vote.');
      const chosen = g.players.find(p => p.id === chosenId)!;
      addLog({ type: 'speech', speaker: `${human.name} (you)`, text: `I vote for ${displayName(chosen, gRef.current)}.`, isYou: true });
      votes.push(chosenId);
      voteLog.push({ voterName: human.name, targetName: chosen.name });
    }

    // AI votes
    const aiVoters = g.players.filter(p => p.alive && !p.isHuman);
    setUI({ tag: 'idle', status: 'AI players are voting…' });
    for (const voter of aiVoters) {
      addLog({ type: 'thinking', speaker: voter.name, text: '…' });
      const vid = await getAIVote(gRef.current, voter, excludeIds);
      removeThinking(voter.name);
      const vtarget = gRef.current.players.find(p => p.id === vid)!;
      addLog({ type: 'speech', speaker: displayName(voter, gRef.current), text: `I vote for ${displayName(vtarget, gRef.current)}.` });
      votes.push(vid);
      voteLog.push({ voterName: voter.name, targetName: vtarget.name });
      await sleep(120);
    }

    // Tally
    const tally = tallyVotes(votes);
    const tallyStr = Object.entries(tally)
      .map(([id, c]) => { const p = gRef.current.players.find(x => x.id === +id)!; return `${displayName(p, gRef.current)}(${c})`; })
      .join(', ');
    addLog({ type: 'system', text: `Votes: ${tallyStr}` });

    const top = topVoted(tally);

    // ── TIE? ──────────────────────────────────
    if (top.length > 1) {
      const tiedPlayers = top.map(id => gRef.current.players.find(p => p.id === id)!).filter(Boolean);
      addLog({ type: 'system', text: `It's a tie! ${tiedPlayers.map(p => displayName(p, gRef.current)).join(' and ')} must prove their innocence!` });
      await sleep(400);

      // Each tied player makes their defense
      for (const accused of tiedPlayers) {
        if (!accused.isHuman) {
          addLog({ type: 'thinking', speaker: accused.name, text: '…' });
          const defense = await getAIDefense(gRef.current, accused);
          removeThinking(accused.name);
          addLog({ type: 'speech', speaker: displayName(accused, gRef.current), text: defense });
        } else {
          const stmt = await waitForSpeak();
          addLog({ type: 'speech', speaker: `${accused.name} (you)`, text: stmt, isYou: true });
        }
        await sleep(200);
      }

      // Revote — can only vote for the tied players
      addLog({ type: 'system', text: `Revote! Choose between the accused.` });
      return await runVoting(gRef.current, gRef.current.players.filter(p => p.alive && !top.includes(p.id)).map(p => p.id));
      // (voteLog from revote is returned by recursive call)
    }

    // ── ELIMINATE ─────────────────────────────
    const elimId = top[0];
    if (elimId == null) return null;

    mutateG(prev => ({
      ...prev,
      players: prev.players.map(p => p.id === elimId ? { ...p, alive: false } : p),
    }));
    const ep = gRef.current.players.find(p => p.id === elimId)!;
    addLog({ type: 'death', text: `${ep.name} was eliminated. They were ${ep.role === 'mafia' ? '☠ MAFIA' : `a ${ep.role}`}.` });
    return { elimId, voteLog };
  }

  // ══════════════════════════════════════════════
  // NIGHT PHASE
  // ══════════════════════════════════════════════
  async function runNight(g: GameState): Promise<{ killed: { name: string; role: Role } | null; saved: boolean }> {
    const human = g.players[0];
    const mafiaAlive = g.players.filter(p => p.alive && p.role === 'mafia');

    // Build narration lines
    const lines: {text:string;color:string}[] = [
      { text: '…',                               color: 'grey'  },
      { text: 'Night falls over the village.',   color: 'blue'  },
      { text: 'The villagers close their eyes.', color: 'grey'  },
      { text: '',                                color: 'grey'  },
      { text: 'Mafia, wake up.',                 color: 'red'   },
    ];

    if (human.role === 'mafia') {
      const partner = mafiaAlive.find(p => p.id !== human.id);
      lines.push({ text: `You lock eyes with ${partner?.name ?? '???'} across the dark room.`, color: 'red' });
      lines.push({ text: 'Together, you decide who must go.',                                   color: 'red' });
    } else {
      lines.push({ text: 'You barely manage to catch some hushed whispers…',                    color: 'grey' });
      lines.push({ text: '"??? and ??? seem to be deciding who to kill."',                       color: 'grey' });
    }

    lines.push({ text: 'Mafia, go to sleep.', color: 'grey' });

    const detAlive = g.players.some(p => p.alive && p.role === 'detective');
    if (detAlive) {
      lines.push({ text: '',                  color: 'grey' });
      lines.push({ text: 'Detective, wake up.', color: 'blue' });
      if (human.role === 'detective') {
        lines.push({ text: 'You slip silently through the shadows to investigate.', color: 'blue' });
      } else {
        lines.push({ text: 'A shadow moves quietly through the village…', color: 'grey' });
      }
      lines.push({ text: 'Detective, go to sleep.', color: 'grey' });
    }

    const docAlive = g.players.some(p => p.alive && p.role === 'doctor');
    if (docAlive) {
      lines.push({ text: '',                color: 'grey'  });
      lines.push({ text: 'Doctor, wake up.', color: 'green' });
      if (human.role === 'doctor') {
        lines.push({ text: 'You quietly choose who to protect tonight.', color: 'green' });
      } else {
        lines.push({ text: 'Somewhere, a guardian keeps watch…', color: 'grey' });
      }
      lines.push({ text: 'Doctor, go to sleep.', color: 'grey' });
    }

    lines.push({ text: '',                   color: 'grey'   });
    lines.push({ text: 'Everyone, wake up.', color: 'yellow' });

    await playNarration(lines);

    // ── AI night actions ──────────────────────
    let killId: number | null = null;
    let saveId: number | null = null;

    if (human.role !== 'mafia') {
      killId = await getAIMafiaKill(gRef.current);
    }

    const detTarget = getAIDetectiveTarget(gRef.current);
    if (detTarget !== null) {
      const tp = gRef.current.players.find(p => p.id === detTarget)!;
      mutateG(prev => ({
        ...prev,
        investigateResults: { ...prev.investigateResults, [detTarget]: tp.role === 'mafia' ? 'mafia' : 'innocent' },
      }));
    }

    if (human.role !== 'doctor') {
      saveId = getAIDoctorTarget(gRef.current) ?? null;
    }

    // ── Human night action ────────────────────
    if (human.alive) {
      if (human.role === 'mafia') {
        const targets = gRef.current.players.filter(p => p.alive && p.role !== 'mafia');
        const tid = await waitForSelect(targets, 'MAFIA: Choose your kill target. ↑↓ + Enter.');
        killId = tid;
        addLog({ type: 'night', text: `You mark ${gRef.current.players.find(p=>p.id===tid)!.name} for death.` });
      } else if (human.role === 'detective') {
        const targets = gRef.current.players.filter(p => p.alive && !p.isHuman && !gRef.current.investigateResults[p.id]);
        if (targets.length) {
          const tid = await waitForSelect(targets, 'DETECTIVE: Choose who to investigate. ↑↓ + Enter.');
          const alignment = gRef.current.players.find(p => p.id === tid)!.role === 'mafia' ? 'mafia' : 'innocent';
          mutateG(prev => ({ ...prev, investigateResults: { ...prev.investigateResults, [tid]: alignment } }));
          addLog({ type: 'reveal', text: `You investigate ${gRef.current.players.find(p=>p.id===tid)!.name}… ${alignment === 'mafia' ? '⚠ MAFIA!' : '✓ innocent.'}` });
        }
      } else if (human.role === 'doctor') {
        const targets = gRef.current.players.filter(p => p.alive);
        const tid = await waitForSelect(targets, 'DOCTOR: Choose who to protect. ↑↓ + Enter.');
        saveId = tid;
        addLog({ type: 'night', text: `You keep watch over ${gRef.current.players.find(p=>p.id===tid)!.name}.` });
      }
    }

    // ── Resolve kill ──────────────────────────
    setUI({ tag: 'idle', status: '' });
    await sleep(400);

    let killedRecord: { name: string; role: Role } | null = null;
    let savedRecord = false;

    if (killId !== null) {
      if (killId === saveId) {
        savedRecord = true;
        addLog({ type: 'save', text: `Dawn breaks. Someone was targeted — but a guardian intervened.` });
      } else {
        const victim = gRef.current.players.find(p => p.id === killId)!;
        if (victim?.alive) {
          killedRecord = { name: victim.name, role: victim.role };
          mutateG(prev => ({ ...prev, players: prev.players.map(p => p.id === killId ? { ...p, alive: false } : p) }));
          addLog({ type: 'death', text: `Dawn breaks. ${victim.name} was found dead. They were a ${victim.role}.` });
        }
      }
    } else {
      addLog({ type: 'system', text: `Dawn breaks. The village is unharmed.` });
    }

    return { killed: killedRecord, saved: savedRecord };
  }

  // ══════════════════════════════════════════════
  // RENDER
  // ══════════════════════════════════════════════
  if (winner) return <WinScreen winner={winner} G={G} onRestart={onRestart} />;

  const human = G.players[0];
  const isNight = ui.tag === 'night-narrate' || (ui.tag === 'select' && ui.prompt.startsWith('MAFIA') || ui.tag === 'select' && ui.prompt.startsWith('DETECTIVE') || ui.tag === 'select' && ui.prompt.startsWith('DOCTOR'));
  const phaseLabel = isNight ? `🌑 Night ${G.day}` : `☀  Day ${G.day}`;

  // cursor targets for rendering
  const cursorTargets = (ui.tag === 'select' || ui.tag === 'tiebreak') ? ui.targets : [];
  const selectedId = cursorTargets[cursorIdx]?.id;

  return (
    <Box flexDirection="column" padding={1}>
      <Text color="yellowBright" bold>THE VILLAGE SLEEPS  —  MAFIA</Text>
      <HR />

      {/* Status bar */}
      <Box marginTop={1} marginBottom={1}>
        <Text color={isNight ? 'blue' : 'yellow'}>{phaseLabel}  </Text>
        <Text color="grey">│  Role: </Text>
        <Text color={rc(human.role)} bold>{human.role}</Text>
        <Text color="grey">  │  Alive: </Text>
        <Text color="white">{G.players.filter(p=>p.alive).length}</Text>
      </Box>

      <PlayerRoster G={G} selectedId={selectedId} showCursor={ui.tag === 'select' || ui.tag === 'tiebreak'} />
      <GameLog log={G.log} />

      {/* Night narration */}
      {ui.tag === 'night-narrate' && (
        <Box flexDirection="column" borderStyle="single" borderColor="blue" paddingX={2} paddingY={1} marginBottom={1}>
          {ui.lines.slice(0, ui.shown).map((l, i) => (
            <Text key={i} color={l.color as any} italic={l.color === 'grey'}>{l.text || ' '}</Text>
          ))}
        </Box>
      )}

      {/* Speak input */}
      {ui.tag === 'speak' && (
        <Box>
          <Text color="white">You: </Text>
          <TextInput
            value={speakText}
            onChange={setSpeakText}
            placeholder="Say something to the village…"
            onSubmit={(val) => {
              if (!val.trim()) return;
              setSpeakText('');
              resolveInput.current?.(val.trim());
              resolveInput.current = null;
            }}
          />
        </Box>
      )}

      {/* Select / tiebreak cursor */}
      {(ui.tag === 'select' || ui.tag === 'tiebreak') && (
        <Box flexDirection="column" marginTop={1}>
          {ui.tag === 'tiebreak' && (
            <Box marginBottom={1} flexDirection="column">
              <Text color="red" bold>⚖  TIEBREAKER — The accused have spoken. Now revote.</Text>
            </Box>
          )}
          <Text color="yellow" italic>{ui.prompt}</Text>
          {ui.targets.map((p, i) => {
            const sel = i === cursorIdx;
            return (
              <Box key={p.id}>
                <Text color={sel ? 'yellowBright' : 'grey'}>{sel ? '▶ ' : '  '}</Text>
                <Text color={sel ? 'yellowBright' : 'white'} bold={sel}>{displayName(p, G)}</Text>
              </Box>
            );
          })}
          <Box marginTop={1}><Text color="grey" italic>↑↓ move  ·  Enter confirm</Text></Box>
        </Box>
      )}

      {/* Idle status */}
      {ui.tag === 'idle' && ui.status && (
        <Text color="grey" italic dimColor>{ui.status}</Text>
      )}
    </Box>
  );
}

// ═══════════════════════════════════════════════
// ROOT
// ═══════════════════════════════════════════════
type Screen = 'setup' | { tag: 'wheel'; g: GameState } | { tag: 'game'; g: GameState };

function App() {
  const [screen, setScreen] = useState<Screen>('setup');

  function handleStart(name: string, model: string) {
    const g = createGame(name, model);
    setScreen({ tag: 'wheel', g });
  }

  function handleRestart() { setScreen('setup'); }

  if (screen === 'setup') return <SetupScreen onStart={handleStart} />;
  if (typeof screen === 'object' && screen.tag === 'wheel') {
    return <WheelScreen role={screen.g.players[0].role} onDone={() => setScreen({ tag: 'game', g: screen.g })} />;
  }
  if (typeof screen === 'object' && screen.tag === 'game') {
    return <GameScreen key={screen.g.day} initialG={screen.g} onRestart={handleRestart} />;
  }
  return null;
}

render(<App />);
